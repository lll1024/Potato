# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: answer-model-live.spec.ts >> 当前配置模型在 Web 与 iOS 联合验收中真实分批显示
- Location: tests/ui/answer-model-live.spec.ts:7:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "completed"
Received: "terminated"
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "助手会话导航" [ref=e4]:
    - generic [ref=e5]:
      - heading "Potato" [level=1] [ref=e9]
      - button "收起会话导航" [ref=e10] [cursor=pointer]
    - button "新会话" [ref=e13] [cursor=pointer]
    - complementary "历史会话" [ref=e16]:
      - list [ref=e17]:
        - listitem [ref=e18]:
          - button "我会接着提供旅行需求，请简短回复收到，不查询资料。 已终止" [active] [ref=e19] [cursor=pointer]:
            - strong [ref=e20]:
              - generic [ref=e23]: 我会接着提供旅行需求，请简短回复收到，不查询资料。
            - generic [ref=e24]: 已终止
          - button "会话操作“我会接着提供旅行需求，请简短回复收到，不查询资料。”" [ref=e25] [cursor=pointer]
  - main [ref=e30]:
    - generic [ref=e31]:
      - heading "我会接着提供旅行需求，请简短回复收到，不查询资料。" [level=2] [ref=e33]
      - button "旅行者偏好" [ref=e34] [cursor=pointer]
    - region "我会接着提供旅行需求，请简短回复收到，不查询资料。" [ref=e35]:
      - navigation "会话视图" [ref=e36]:
        - button "对话" [pressed] [ref=e37] [cursor=pointer]
        - button "轨迹" [ref=e38] [cursor=pointer]
        - status [ref=e39]: 终止：输出达到上限
      - status [ref=e41]: 停留底部时跟随新回答
      - generic [ref=e42]:
        - region "第 1 轮对话" [ref=e43]:
          - generic [ref=e44]:
            - paragraph [ref=e45]: 第 1 轮 · 已完成
            - button "查看本轮轨迹" [ref=e46] [cursor=pointer]
          - article [ref=e47]:
            - heading "你的输入" [level=3] [ref=e48]
            - paragraph [ref=e49]: 我会接着提供旅行需求，请简短回复收到，不查询资料。
          - region "第 1 轮处理进展" [ref=e50]:
            - generic [ref=e51]:
              - status [ref=e52]: 已完成
              - generic [ref=e53]: 已用时 1 秒
          - article [ref=e54]:
            - generic [ref=e55]:
              - heading "旅行助手" [level=3] [ref=e56]
              - generic [ref=e57]: 模型回答
            - paragraph [ref=e59]: 收到。请继续提供旅行需求。
            - button "复制完整回答" [ref=e60] [cursor=pointer]
        - region "第 2 轮对话" [ref=e61]:
          - generic [ref=e62]:
            - paragraph [ref=e63]: 第 2 轮 · 终止：输出达到上限
            - button "查看本轮轨迹" [ref=e64] [cursor=pointer]
          - article [ref=e65]:
            - heading "你的输入" [level=3] [ref=e66]
            - paragraph [ref=e67]: 请安排公历2026年11月14日杭州一天旅行，两位成人从杭州东站出发，晚上回杭州东站。请实际查找西湖和中国茶叶博物馆的地点资料、两地公共交通及开放／预约信息，区分未核实内容，给出含交通和来源的详细中文旅行行程。请用简短中文说明正在查什么；不要把准备查询写成查询成功。
          - region "第 2 轮异常提示" [ref=e68]:
            - button "重新尝试" [ref=e69] [cursor=pointer]
            - status [ref=e73]: 回答达到输出上限
            - generic [ref=e74]: 使用原需求创建新对话轮次，可能再次查询；保留输入框草稿。
          - region "查询进展" [ref=e75]:
            - generic "查询进展 （24 项）" [ref=e76] [cursor=pointer]:
              - text: 查询进展
              - generic [ref=e77]: （24 项）
          - article [ref=e78]:
            - generic [ref=e79]:
              - heading "旅行助手" [level=3] [ref=e80]
              - generic [ref=e81]: 模型回答
            - paragraph [ref=e82]: 回答不完整
            - generic [ref=e83]:
              - heading "2026年11月14日（星期六）杭州一日行程" [level=2] [ref=e84]
              - paragraph [ref=e85]:
                - strong [ref=e86]: 2位成人｜杭州东站出发并返回杭州东站
              - paragraph [ref=e87]:
                - strong [ref=e88]: 行程假设
                - text: ：西湖游览段选
                - strong [ref=e89]: 断桥残雪—白堤—湖滨公园
                - text: 一带；中国茶叶博物馆选
                - strong [ref=e90]: 双峰馆区
                - text: （龙井路88号），不去龙井馆区。若你想改为龙井馆区或增加雷峰塔、灵隐，需重新调整交通与时间。
              - separator [ref=e91]
              - heading "一、当天安排（时间为建议，非已确认的开放或班次时刻）" [level=2] [ref=e92]
              - region "回答表格，可横向滚动" [ref=e93]:
                - table [ref=e94]:
                  - rowgroup [ref=e95]:
                    - row [ref=e96]:
                      - columnheader "时间" [ref=e97]
                      - columnheader "安排" [ref=e98]
                      - columnheader "说明" [ref=e99]
                  - rowgroup [ref=e100]:
                    - row [ref=e101]:
                      - cell "08:20—09:05" [ref=e102]
                      - cell "杭州东站→断桥残雪" [ref=e103]
                      - cell "地铁1号线＋277路，约44分钟" [ref=e104]
                    - row [ref=e105]:
                      - cell "09:05—10:50" [ref=e106]
                      - cell "断桥残雪、白堤一带漫步拍照" [ref=e107]
                      - cell "建议时长，实际以体力为准" [ref=e108]
                    - row [ref=e109]:
                      - cell "10:50—11:07" [ref=e110]
                      - cell "断桥残雪→午餐餐馆" [ref=e111]
                      - cell "步行约1.3公里、约17分钟" [ref=e112]
                    - row [ref=e113]:
                      - cell "11:10—12:20" [ref=e114]
                      - cell "湖滨午餐" [ref=e115]
                      - cell "杭帮菜馆·老底子杭帮菜（西湖店）" [ref=e116]
                    - row [ref=e117]:
                      - cell "12:20—12:27" [ref=e118]
                      - cell "餐馆→小车桥公交站" [ref=e119]
                      - cell "步行约232米，包含在下一段路线内" [ref=e120]
                    - row [ref=e121]:
                      - cell "12:27—13:17" [ref=e122]
                      - cell "小车桥→双峰（茶博双峰馆区）" [ref=e123]
                      - cell "27路，全程约50分钟" [ref=e124]
                    - row [ref=e125]:
                      - cell "13:20—16:00" [ref=e126]
                      - cell "参观中国茶叶博物馆双峰馆区" [ref=e127]
                      - cell "馆方指南开放至16:30，建议16:00前离馆" [ref=e128]
                    - row [ref=e129]:
                      - cell "16:00—16:07" [ref=e130]
                      - cell "茶博→双峰公交站" [ref=e131]
                      - cell "步行约398米，包含在返程路线内" [ref=e132]
                    - row [ref=e133]:
                      - cell "16:07—17:20" [ref=e134]
                      - cell "双峰→杭州东站" [ref=e135]
                      - cell "87路＋地铁3号线＋地铁1号线，约73分钟" [ref=e136]
                    - row [ref=e137]:
                      - cell "17:20后" [ref=e138]
                      - cell "杭州东站" [ref=e139]
                      - cell "建议预留至少40—60分钟进站候车" [ref=e140]
              - blockquote [ref=e141]:
                - paragraph [ref=e142]:
                  - text: 晚上返程若已购车票，建议选择
                  - strong [ref=e143]: 18:20以后
                  - text: 从杭州东站出发的车次，给公交、地铁换乘和进站留出余量。以上到站时间为按地图耗时估算，未包含等车、拥堵和步行休息。
              - separator [ref=e144]
              - heading "二、逐段交通（均为本次地图查询结果）" [level=2] [ref=e145]
              - list [ref=e146]:
                - listitem [ref=e147]:
                  - paragraph [ref=e148]:
                    - strong [ref=e149]: 杭州东站 → 杭州西湖风景名胜区-断桥残雪｜地铁＋公交，约9.5公里，约44分钟
                  - list [ref=e150]:
                    - listitem [ref=e151]:
                      - text: 地铁1号线（萧山国际机场--湘湖）：
                      - strong [ref=e152]: 火车东站
                      - text: 上车 →
                      - strong [ref=e153]: 凤起路
                      - text: 下车；
                    - listitem [ref=e154]:
                      - text: 277路（龙翔桥公交站--西溪湿地北总站）：
                      - strong [ref=e155]: 孩儿巷1
                      - text: 上车 →
                      - strong [ref=e156]: 少年宫
                      - text: 下车；
                    - listitem [ref=e157]: 下车后步行约558米到断桥残雪。
                    - listitem [ref=e158]: 另一方案：地铁1号线到凤起路后直接步行约1.5公里，总耗时也约44分钟，但步行更多。
                - listitem [ref=e159]:
                  - paragraph [ref=e160]:
                    - strong [ref=e161]: 断桥残雪 → 杭帮菜馆·老底子杭帮菜（西湖店）｜步行，约1.3公里，约17分钟
                - listitem [ref=e162]:
                  - paragraph [ref=e163]:
                    - strong [ref=e164]: 杭帮菜馆·老底子杭帮菜（西湖店） → 中国茶叶博物馆（双峰馆区）｜公交，约6.5公里，约50分钟
                  - list [ref=e165]:
                    - listitem [ref=e166]:
                      - text: 步行约232米到
                      - strong [ref=e167]: 小车桥
                      - text: ；
                    - listitem [ref=e168]:
                      - text: 27路（岳王路--茶博龙井馆区）：
                      - strong [ref=e169]: 小车桥
                      - text: 上车 →
                      - strong [ref=e170]: 双峰
                      - text: 下车；
                    - listitem [ref=e171]: 下车后步行约458米到双峰馆区。
                    - listitem [ref=e172]: 地图另显示27B路、27路（17点后）也走小车桥—双峰，但当天实际班次未核实。
                - listitem [ref=e173]:
                  - paragraph [ref=e174]:
                    - strong [ref=e175]: 中国茶叶博物馆（双峰馆区） → 杭州东站｜公交＋地铁，约15.3公里，约73分钟
                  - list [ref=e176]:
                    - listitem [ref=e177]:
                      - text: 步行约398米到
                      - strong [ref=e178]: 双峰
                      - text: ；
                    - listitem [ref=e179]:
                      - text: 87路（水澄桥--黄龙公交总站）：
                      - strong [ref=e180]: 双峰
                      - text: 上车 →
                      - strong [ref=e181]: 黄龙洞
                      - text: 下车；
                    - listitem [ref=e182]:
                      - text: 地铁3号线（石马--星桥）：
                      - strong [ref=e183]: 黄龙洞
                      - text: 上车 →
                      - strong [ref=e184]: 西湖文化广场
                      - text: 下车；
                    - listitem [ref=e185]:
                      - text: 地铁1号线（湘湖--萧山国际机场）：
                      - strong [ref=e186]: 西湖文化广场
                      - text: 上车 →
                      - strong [ref=e187]: 火车东站
                      - text: 下车。
                    - listitem [ref=e188]: 备选：180路（钱江湾花园总站--金色蓝庭总站）里鸡笼山→皇朝花园（五联村），换地铁19号线（火车西站--永盛路）五联→火车东站（东广场），全程约68分钟，但步行约1.3公里，较费力。
              - blockquote [ref=e189]:
                - paragraph [ref=e190]: 地图工具未说明上述耗时是否包含候车时间，不能视为实时班次或时刻表。
              - separator [ref=e191]
              - heading "三、开放、门票与预约信息（区分已取得与未核实）" [level=2] [ref=e192]
              - heading "1. 西湖风景名胜区—断桥残雪、湖滨公园" [level=3] [ref=e193]
              - list [ref=e194]:
                - listitem [ref=e195]:
                  - text: 高德地点详情显示：
                  - strong [ref=e196]: 断桥残雪、湖滨公园均为24小时营业
                  - text: ；断桥残雪标注为国家级景点、AAAAA级。
                - listitem [ref=e197]:
                  - text: 本地宝2026年景区攻略称：西湖风景名胜区
                  - strong [ref=e198]: 全天开放、门票免费
                  - text: ；该资料同时列出雷峰塔、灵隐飞来峰、岳王庙等收费景点的开放时间和提前购票天数。以上属于第三方攻略摘录，
                  - strong [ref=e199]: 不是管委会官方公告正文
                  - text: 。
                - listitem [ref=e200]:
                  - text: 西湖管委会官网本次取得的页面只有景区概况和西湖十景名录，
                  - strong [ref=e201]: 未取得核心湖区开放时段、门票或预约规则的官方明文
                  - text: 。
                - listitem [ref=e202]:
                  - text: 2023年3月31日杭州市政府网站转载报道称：西湖景区17处收费公园景点恢复收费，且进入这些公园景点仍需预约，渠道包括“掌上西湖西溪”小程序和“西湖旅游”等微信公众号。该规则是
                  - strong [ref=e203]: 2023年的报道
                  - text: ，不能直接套用到2026年11月14日。
                - listitem [ref=e204]: 2026年9月8日杭州市政协网转载报道称：9—11月双休日、节假日，灵隐飞来峰景区需提前实名预约；未提及断桥、白堤、湖滨公园需要预约。该报道的交通管理内容适用于11月14日（周六），但是否适用于所有收费景点，资料没有完整说明。
                - listitem [ref=e205]:
                  - strong [ref=e206]: 结论
                  - text: ：本次行程只进入断桥、白堤、湖滨公园一带，未取得2026年11月14日这些区域需要购票或预约的官方明文；按免费开放区域安排，出行前建议在“西湖旅游”微信公众号或“掌上西湖西溪”小程序再核对当日政策。收费景点和游船若临时加入，需另行购票／预约，具体待核实。
              - paragraph [ref=e207]:
                - strong [ref=e208]: 西湖游船（可选，不列入主行程）
                - text: ：杭州市文化广电旅游局2022年页面列明，湖滨一公园码头休闲船上岛游票价55元/人，手划船150元/小时·船、摇橹船180元/小时·船。该页面发布时间为2022年12月，
                - strong [ref=e209]: 现价、班次和当日运营情况待核实
                - text: 。
              - heading "2. 中国茶叶博物馆（双峰馆区）" [level=3] [ref=e210]
              - list [ref=e211]:
                - listitem [ref=e212]:
                  - text: 中国茶叶博物馆网站《参观指南》正文显示：
                  - strong [ref=e213]: 开放时间9:00—16:30；每周二为闭馆日，节假日照常开放
                  - text: 。该页面未取得发布日期。
                - listitem [ref=e214]:
                  - text: 高德地点详情显示：双峰馆区
                  - strong [ref=e215]: 周二全天不开放；周一、周三至周日09:00—16:30开放
                  - text: ；元旦、春节、清明、劳动节、端午、中秋、国庆09:00—16:30开放。与馆方指南的周二闭馆规则一致。
                - listitem [ref=e216]:
                  - text: 2026年11月14日是
                  - strong [ref=e217]: 星期六
                  - text: ，按上述常规规则不在闭馆日；但这是常规规则，
                  - strong [ref=e218]: 不能据此确认11月14日当天一定开放
                  - text: ，出行前仍需自行确认。
                - listitem [ref=e219]:
                  - text: 预约：本地宝2026年8月6日转载的“中国茶叶博物馆关于优化开放服务实行免预约入馆的公告”称：双峰馆区和龙井馆区
                  - strong [ref=e220]: 全面实行免预约入馆，散客无需线上预约，到馆配合安全检查即可
                  - text: ；团队参观、研学活动需提前准备加盖单位公章的人员名单，发送至官方邮箱或当日提交纸质件。该来源为第三方转载，
                  - strong [ref=e221]: 不是馆方网站正文
                  - text: ，只能表述为“该资料称”。
                - listitem [ref=e222]:
                  - text: 馆方《参观指南》正文本次
                  - strong [ref=e223]: 未提及预约要求
                  - text: ；不能由“未提及”推断一定无需预约。
                - listitem [ref=e224]:
                  - text: 门票：馆方《参观指南》正文本次
                  - strong [ref=e225]: 未取得票价说明
                  - text: ；有第三方资料称常年免费开放，待核实。
              - heading "3. 专项核实说明（仅针对本次开放／预约问题）" [level=3] [ref=e226]
              - region "回答表格，可横向滚动" [ref=e227]:
                - table [ref=e228]:
                  - rowgroup [ref=e229]:
                    - row [ref=e230]:
                      - columnheader "来源" [ref=e231]
                      - columnheader "实际链接" [ref=e232]
                      - columnheader "正文读取状态" [ref=e233]
                      - columnheader "查询时间（Asia/Shanghai）" [ref=e234]
                      - columnheader "来源发布日期" [ref=e235]
                      - columnheader "规则适用范围与已知影响" [ref=e236]
                  - rowgroup [ref=e237]:
                    - row [ref=e238]:
                      - cell "中国茶叶博物馆网站《参观指南》" [ref=e239]
                      - cell [ref=e240]:
                        - link "https://www.teamuseum.cn/mobile/basicIntroduction.htm" [ref=e241] [cursor=pointer]:
                          - /url: https://www.teamuseum.cn/mobile/basicIntroduction.htm
                      - cell "已读取正文（page_body）" [ref=e242]
                      - cell "2026-11-09 14:23" [ref=e243]
                      - cell "未取得" [ref=e244]
                      - cell "全馆常规开放9:00—16:30、周二闭馆；与11月14日周六不冲突，但未确认当日一定开放" [ref=e245]
                    - row [ref=e246]:
                      - cell "本地宝转载“免预约入馆公告”" [ref=e247]
                      - cell [ref=e248]:
                        - link "http://hz.bendibao.com/tour/202686/172159.shtm" [ref=e249] [cursor=pointer]:
                          - /url: http://hz.bendibao.com/tour/202686/172159.shtm
                      - cell "仅搜索摘录（search_clues）" [ref=e250]
                      - cell "2026-11-09 14:23" [ref=e251]
                      - cell "2026-08-06" [ref=e252]
                      - cell "称双峰、龙井两馆区散客免预约、到馆安检；来源身份非馆方，不能作为馆方最终确认" [ref=e253]
                    - row [ref=e254]:
                      - cell "杭州市政府网站转载报道" [ref=e255]
                      - cell [ref=e256]:
                        - link "https://www.hangzhou.gov.cn/art/2023/3/31/art_812269_59077483.html" [ref=e257] [cursor=pointer]:
                          - /url: https://www.hangzhou.gov.cn/art/2023/3/31/art_812269_59077483.html
                      - cell "仅搜索摘录" [ref=e258]
                      - cell "2026-11-09 14:23" [ref=e259]
                      - cell "2023-03-31" [ref=e260]
                      - cell "2023年4月1日起收费公园景点恢复收费并需预约；对2026-11-14不直接适用" [ref=e261]
                    - row [ref=e262]:
                      - cell "杭州市政协网转载报道" [ref=e263]
                      - cell [ref=e264]:
                        - link "https://www.hzzx.gov.cn/cshz/content/2026-09/08/content_9301630.htm" [ref=e265] [cursor=pointer]:
                          - /url: https://www.hzzx.gov.cn/cshz/content/2026-09/08/content_9301630.htm
                      - cell "仅搜索摘录" [ref=e266]
                      - cell "2026-11-09 14:23" [ref=e267]
                      - cell "2026-09-08" [ref=e268]
                      - cell "2026年9—11月双休日交通管理；明确灵隐飞来峰需预约，未提断桥、湖滨预约" [ref=e269]
                    - row [ref=e270]:
                      - cell "本地宝西湖攻略" [ref=e271]
                      - cell [ref=e272]:
                        - link "http://hz.bendibao.com/jingdian/hzxihu/" [ref=e273] [cursor=pointer]:
                          - /url: http://hz.bendibao.com/jingdian/hzxihu/
                      - cell "仅搜索摘录" [ref=e274]
                      - cell "2026-11-09 14:23" [ref=e275]
                      - cell "未取得" [ref=e276]
                      - cell "称西湖全天开放、免费；第三方攻略，非官方公告" [ref=e277]
                    - row [ref=e278]:
                      - cell "高德地图地点详情" [ref=e279]
                      - cell "本次地图工具结果（无独立网页链接）" [ref=e280]
                      - cell "已取得地点详情字段" [ref=e281]
                      - cell "2026-11-09 14:23" [ref=e282]
                      - cell "未取得" [ref=e283]
                      - cell "断桥残雪、湖滨公园24小时营业；茶博周二闭馆、其余日9:00—16:30" [ref=e284]
              - blockquote [ref=e285]:
                - paragraph [ref=e286]: 上述搜索摘录可能被截断；未取得的内容不代表不存在。票价、预约、当日临时闭馆或限流信息，请在出发前自行核实。
              - separator [ref=e287]
              - heading "四、餐饮建议" [level=2] [ref=e288]
              - paragraph [ref=e289]:
                - strong [ref=e290]: 杭帮菜馆·老底子杭帮菜（西湖店）
              - list [ref=e291]:
                - listitem [ref=e292]: 地址：长生路58号西湖国贸中心F2层（高德返回）
                - listitem [ref=e293]: 高德返回：餐饮类型“中餐厅”；人均约48元；评分3.8；营业时间10:00—22:00。
                - listitem [ref=e294]: 推荐理由：店名含“杭帮菜”，位于湖滨，距断桥步行约1.3公里、距小车桥公交站步行约232米，便于接续下午去茶博的27路。
                - listitem [ref=e295]: 待核实：具体菜单、菜品是否清淡少辣、当日营业和排队情况均未取得。点餐时可询问店家能否做清淡少辣的杭帮菜；评分和
            - button "复制不完整回答" [ref=e296] [cursor=pointer]
      - generic [ref=e298]:
        - generic [ref=e299]: 旅行需求
        - textbox "旅行需求" [ref=e300]:
          - /placeholder: 写下城市、日期和你想查询的内容…
        - generic [ref=e301]:
          - paragraph [ref=e302]: 继续此会话 · 切换会话保留草稿
          - button "发送旅行需求" [disabled] [ref=e303]:
            - generic [ref=e306]: 发送
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test';
  2   | import { writeFile } from 'node:fs/promises';
  3   | 
  4   | test.use({ignoreHTTPSErrors: true, video: 'on'});
  5   | 
  6   | // 由 iOS 原界面发起，两端在真实准备轮之后进入同一会话，再观测完整目标轮。
  7   | test('当前配置模型在 Web 与 iOS 联合验收中真实分批显示', async ({page}) => {
  8   |   test.skip(process.env.POTATO_LIVE_ANSWER !== '1', '仅在显式真实模型联合验收时运行');
  9   |   test.setTimeout(900_000);
  10  |   const url = 'https://localhost:18499';
  11  |   const get = async (path: string) => (await page.request.get(url + path)).json();
  12  |   const mark = async (key: string, data: object) => page.request.post(url + '/__acceptance__/coordination/' + key, {data});
  13  |   const environment = await get('/__acceptance__/environment');
  14  |   expect(environment.kind).toBe('configured-model-answer-acceptance');
  15  |   await page.addInitScript(() => {
  16  |     const evidence = {receipts: [] as object[], rendered: [] as object[]};
  17  |     (window as any).__liveEvidence = evidence;
  18  |     const Native = window.EventSource;
  19  |     window.EventSource = class extends Native {
  20  |       constructor(address: string | URL, options?: EventSourceInit) {
  21  |         super(address, options);
  22  |         for (const kind of ['answer.preview', 'progress.preview', 'service.state']) {
  23  |           this.addEventListener(kind, event => {
  24  |             const notice = JSON.parse((event as MessageEvent).data);
  25  |             const value = kind === 'service.state' ? notice.state : notice.preview;
  26  |             evidence.receipts.push({epoch_ms: Date.now(), monotonic_ms: performance.now(), kind,
  27  |               content: value == null ? null : {
  28  |                 instance_id: value.instance_id, stream_id: value.stream_id, session_id: value.session_id,
  29  |                 turn_id: value.turn_id, revision: value.revision, attempt_id: value.attempt_id,
  30  |                 status: value.status, delivery: value.delivery, text_chars: value.text?.length,
  31  |                 entries: value.entries?.map((entry: any) => ({id: entry.id, attempt_id: entry.attempt_id,
  32  |                   kind: entry.kind, status: entry.status, text_chars: entry.text.length})),
  33  |                 active_turn_id: value.active_turn_id,
  34  |               }});
  35  |           });
  36  |         }
  37  |       }
  38  |     };
  39  |     let previous = '';
  40  |     let heartbeat = 0;
  41  |     const sample = () => {
  42  |       const turn = document.querySelector('section[aria-label="第 2 轮对话"]');
  43  |       const body = turn?.querySelector<HTMLElement>('.message.answer .answer-body');
  44  |       const progress = turn?.querySelector<HTMLDetailsElement>('.query-progress');
  45  |       const text = body?.innerText ?? '';
  46  |       const query = progress?.open ? Array.from(progress.querySelectorAll<HTMLElement>('li > span')).map(item => item.innerText).join('\n') : '';
  47  |       const status = progress?.open ? Array.from(progress.querySelectorAll<HTMLElement>('li > small')).map(item => item.innerText) : [];
  48  |       const scroll = document.querySelector('.messages');
  49  |       const state = {rendered_document_chars: text.length, rendered_progress_chars: query.length,
  50  |         progress_open: progress?.open ?? null, progress_statuses: status,
  51  |         copy_label: turn?.querySelector('.message.answer button')?.textContent ?? null,
  52  |         scroll_top: scroll?.scrollTop ?? null, scroll_height: scroll?.scrollHeight ?? null,
  53  |         viewport_height: scroll?.clientHeight ?? null};
  54  |       const serial = JSON.stringify(state);
  55  |       const now = performance.now();
  56  |       if (serial !== previous || now - heartbeat >= 100) {
  57  |         evidence.rendered.push({epoch_ms: Date.now(), monotonic_ms: now, time_origin: performance.timeOrigin, ...state});
  58  |         previous = serial; heartbeat = now;
  59  |       }
  60  |       requestAnimationFrame(sample);
  61  |     };
  62  |     requestAnimationFrame(sample);
  63  |   });
  64  |   await page.goto(url);
  65  |   let coordination: any;
  66  |   await expect.poll(async () => {
  67  |     coordination = await get('/__acceptance__/coordination');
  68  |     return coordination.ios_session?.session_id;
  69  |   }, {timeout: 240_000}).toBeTruthy();
  70  |   const id = coordination.ios_session.session_id;
  71  |   const session = page.locator('.history-select').first();
  72  |   await expect(session).toBeVisible({timeout: 30_000});
  73  |   await session.click();
  74  |   await expect(page.locator('section[aria-label="第 1 轮对话"] .answer-body')).toBeVisible();
  75  |   await mark('web_ready', {session_id: id, at: new Date().toISOString()});
  76  |   let saved: any;
  77  |   await expect.poll(async () => {
  78  |     saved = await get('/api/sessions/' + id + '?summary=false&include_messages=false');
  79  |     return saved.turns[1]?.status;
  80  |   }, {timeout: 600_000, intervals: [500]}).not.toBe(undefined);
  81  |   const target = saved.turns[1].turn_id;
  82  |   await expect.poll(async () => {
  83  |     saved = await get('/api/sessions/' + id + '?summary=false&include_messages=false');
  84  |     return saved.turns[1].status;
  85  |   }, {timeout: 600_000, intervals: [500]}).not.toBe('running');
  86  |   const turn = saved.turns[1];
> 87  |   expect(turn.status).toBe('completed');
      |                       ^ Error: expect(received).toBe(expected) // Object.is equality
  88  |   await expect(page.locator('section[aria-label="第 2 轮对话"]').getByRole('button', {name: '复制完整回答', exact: true})).toBeVisible();
  89  |   await page.waitForTimeout(300);
  90  |   const timeline = await page.evaluate(() => (window as any).__liveEvidence);
  91  |   const samples = timeline.rendered.filter((sample: any) => sample.rendered_document_chars > 0);
  92  |   expect(samples.length).toBeGreaterThan(2);
  93  |   expect(timeline.receipts.some((item: any) => item.kind === 'answer.preview' && item.content?.turn_id === target && item.content.text_chars > 0)).toBeTruthy();
  94  |   const query = page.locator('section[aria-label="第 2 轮对话"] .query-progress');
  95  |   if (environment.scenario === 'query') {
  96  |     expect(turn.query_progress.length).toBeGreaterThan(0);
  97  |     expect(saved.tool_calls.filter((item: any) => item.turn_id === target).length).toBeGreaterThan(0);
  98  |     await expect(query).not.toHaveAttribute('open');
  99  |     expect(timeline.rendered.some((item: any) => item.rendered_progress_chars > 0)).toBeTruthy();
  100 |     await query.locator('summary').click();
  101 |     await expect(query).toHaveAttribute('open');
  102 |   } else {
  103 |     expect(turn.query_progress).toEqual([]);
  104 |     expect(saved.tool_calls.filter((item: any) => item.turn_id === target)).toEqual([]);
  105 |   }
  106 |   await page.screenshot({path: test.info().outputPath('live-saved-expanded.png')});
  107 |   // 系统剪贴板由两端共享：等待手机完成采样，再先由Web复制，最后交手机。
  108 |   await expect.poll(async () => (await get('/__acceptance__/coordination')).ios_saved, {timeout: 120_000}).toBeTruthy();
  109 |   await page.context().grantPermissions(['clipboard-read', 'clipboard-write']);
  110 |   await page.locator('section[aria-label="第 2 轮对话"]').getByRole('button', {name: '复制完整回答', exact: true}).click();
  111 |   expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(turn.answer);
  112 |   await mark('web_copied', {turn_id: target, markdown_equal: true});
  113 |   await page.reload();
  114 |   await page.locator('.history-select').first().click();
  115 |   const history = await get('/api/sessions/' + id + '?summary=false&include_messages=false');
  116 |   expect(history.turns[1].query_progress).toEqual(turn.query_progress);
  117 |   expect(history.turns[1].answer).toBe(turn.answer);
  118 |   if (environment.scenario === 'query') {
  119 |     const reopened = page.locator('section[aria-label="第 2 轮对话"] .query-progress');
  120 |     await expect(reopened).not.toHaveAttribute('open');
  121 |     await reopened.locator('summary').click();
  122 |     await expect(reopened).toContainText('已保存的查询进展');
  123 |   }
  124 |   await page.screenshot({path: test.info().outputPath('live-reopened.png')});
  125 |   const evidence = test.info().outputPath('live-evidence.json');
  126 |   await writeFile(evidence, JSON.stringify({environment, session_id: id, turn_id: target, timeline,
  127 |     outcome: turn, requests: history.requests, tools: history.tool_calls.map((item: any) => ({
  128 |       tool_call_id: item.tool_call_id, turn_id: item.turn_id, name: item.name, status: item.status})),
  129 |     copy_markdown_equal: true, reloaded_progress_equal: true}, null, 2));
  130 |   await test.info().attach('真实模型与 Web 全程证据', {path: evidence, contentType: 'application/json'});
  131 |   await mark('web_finished', {turn_id: target, at: new Date().toISOString()});
  132 | });
  133 | 
```