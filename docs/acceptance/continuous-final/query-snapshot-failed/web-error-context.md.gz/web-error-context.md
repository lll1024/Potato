# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: answer-model-live.spec.ts >> 当前配置模型在 Web 与 iOS 联合验收中真实分批显示
- Location: tests/ui/answer-model-live.spec.ts:7:1

# Error details

```
Error: expect(received).toBeTruthy()

Received: undefined

Call Log:
- Timeout 120000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "助手会话导航" [ref=e4]:
    - generic [ref=e5]:
      - heading "Potato" [level=1] [ref=e9]
      - button "收起会话导航" [ref=e10] [cursor=pointer]
    - button "新会话" [ref=e13] [cursor=pointer]
    - complementary "历史会话" [ref=e16]:
      - list [ref=e17]:
        - listitem [ref=e18]:
          - button "我会接着提供旅行需求，请简短回复收到，不查询资料。 2026/11/8 18:37:26 已完成" [ref=e19] [cursor=pointer]:
            - strong [ref=e20]:
              - generic [ref=e21]: 我会接着提供旅行需求，请简短回复收到，不查询资料。
            - time [ref=e22]: 1分钟
            - generic [ref=e23]: 已完成
          - button "会话操作“我会接着提供旅行需求，请简短回复收到，不查询资料。”"
  - main [ref=e24]:
    - generic [ref=e25]:
      - heading "我会接着提供旅行需求，请简短回复收到，不查询资料。" [level=2] [ref=e27]
      - button "旅行者偏好" [ref=e28] [cursor=pointer]
    - region "我会接着提供旅行需求，请简短回复收到，不查询资料。" [ref=e29]:
      - navigation "会话视图" [ref=e30]:
        - button "对话" [pressed] [ref=e31] [cursor=pointer]
        - button "轨迹" [ref=e32] [cursor=pointer]
        - status [ref=e33]: 已完成
      - status [ref=e35]: 停留底部时跟随新回答
      - generic [ref=e36]:
        - region "第 1 轮对话" [ref=e37]:
          - generic [ref=e38]:
            - paragraph [ref=e39]: 第 1 轮 · 已完成
            - button "查看本轮轨迹" [ref=e40] [cursor=pointer]
          - article [ref=e41]:
            - heading "你的输入" [level=3] [ref=e42]
            - paragraph [ref=e43]: 我会接着提供旅行需求，请简短回复收到，不查询资料。
          - region "第 1 轮处理进展" [ref=e44]:
            - generic [ref=e45]:
              - status [ref=e46]: 已完成
              - generic [ref=e47]: 已用时 1 秒
          - article [ref=e48]:
            - generic [ref=e49]:
              - heading "旅行助手" [level=3] [ref=e50]
              - generic [ref=e51]: 模型回答
            - paragraph [ref=e53]: 收到，请提供旅行需求。
            - button "复制完整回答" [ref=e54] [cursor=pointer]
        - region "第 2 轮对话" [ref=e55]:
          - generic [ref=e56]:
            - paragraph [ref=e57]: 第 2 轮 · 已完成
            - button "查看本轮轨迹" [ref=e58] [cursor=pointer]
          - article [ref=e59]:
            - heading "你的输入" [level=3] [ref=e60]
            - paragraph [ref=e61]: 请安排公历2026年11月14日杭州一天旅行，两位成人从杭州东站出发，晚上回杭州东站。请实际查找西湖和中国茶叶博物馆的地点资料、两地公共交通及开放／预约信息，区分未核实内容，给出含交通和来源的详细中文旅行行程。请用简短中文说明正在查什么；不要把准备查询写成查询成功。
          - region "第 2 轮处理进展" [ref=e62]:
            - generic [ref=e63]:
              - status [ref=e64]: 已完成
              - generic [ref=e65]: 已用时 130 秒
          - region "查询进展" [ref=e66]:
            - generic "查询进展 （27 项）" [active] [ref=e67] [cursor=pointer]:
              - text: 查询进展
              - generic [ref=e68]: （27 项）
            - paragraph [ref=e69]: 已保存的查询进展，取得资料不代表已完成核实
            - list [ref=e70]:
              - listitem [ref=e71]: 先查西湖、中国茶叶博物馆和杭州东站的定位资料，以及11月14日杭州天气，再据此安排并查交通。 行动说明
              - listitem [ref=e72]: 查找地点资料 已取得资料
              - listitem [ref=e73]: 查找地点资料 已取得资料
              - listitem [ref=e74]: 查找地点资料 已取得资料
              - listitem [ref=e75]: 查询天气 已取得资料
              - listitem [ref=e76]: 已定位三处地点，接着查西湖与茶叶博物馆的开放／预约资料，并取各点坐标。 行动说明
              - listitem [ref=e77]: 查找地点资料 已取得资料
              - listitem [ref=e78]: 查找地点资料 已取得资料
              - listitem [ref=e79]: 查找地点资料 已取得资料
              - listitem [ref=e80]: 查找网页资料 已取得资料
              - listitem [ref=e81]: 查找网页资料 已取得资料
              - listitem [ref=e82]: 已取得坐标。接着读取西湖与茶叶博物馆的官方页面正文，并定位湖滨一带的具体游览点。 行动说明
              - listitem [ref=e83]: 查找网页资料 已取得资料
              - listitem [ref=e84]: 查找地点资料 已取得资料
              - listitem [ref=e85]: 查找地点资料 已取得资料
              - listitem [ref=e86]: 官方页面正文已读取。现在查杭州东站—西湖湖滨—茶叶博物馆各段公交方案、湖滨一带餐饮，以及西湖免费开放的官方表述。 行动说明
              - listitem [ref=e87]: 比较交通路线 已取得资料
              - listitem [ref=e88]: 比较交通路线 已取得资料
              - listitem [ref=e89]: 比较交通路线 已取得资料
              - listitem [ref=e90]: 查找地点资料 已取得资料
              - listitem [ref=e91]: 查找网页资料 已取得资料
              - listitem [ref=e92]: 各段公交与湖滨餐饮候选已取得。再定位午餐门店坐标并核对湖滨到断桥的步行段。 行动说明
              - listitem [ref=e93]: 查找地点资料 已取得资料
              - listitem [ref=e94]: 比较交通路线 已取得资料
              - listitem [ref=e95]: 最后核对午餐门店与湖滨、茶叶博物馆之间的衔接交通。 行动说明
              - listitem [ref=e96]: 比较交通路线 已取得资料
              - listitem [ref=e97]: 比较交通路线 已取得资料
          - article [ref=e98]:
            - generic [ref=e99]:
              - heading "旅行助手" [level=3] [ref=e100]
              - generic [ref=e101]: 模型回答
            - generic [ref=e102]:
              - heading "一、行程前提" [level=2] [ref=e103]
              - list [ref=e104]:
                - listitem [ref=e105]: 日期：2026年11月14日（星期六），当天往返，两位成人，起终点均为杭州东站（天城路1号，高德类型“火车站”，营业时间05:00–23:00）。
                - listitem [ref=e106]:
                  - text: 中国茶叶博物馆有两个馆区：双峰馆区（龙井路88号）和龙井馆区（满觉陇路翁家山268号）。
                  - strong [ref=e107]: 本行程按双峰馆区安排
                  - text: （高德评分4.7）；若您想改去龙井馆区，请告知，我需要重新查该馆区的交通衔接。
                - listitem [ref=e108]:
                  - text: 天气：天气工具只返回了11月8日至11日的预报，
                  - strong [ref=e109]: 11月14日无预报数据，天气待核实
                  - text: ，请出行前几天自行查看。
              - heading "二、当天安排（时间为建议，非已确认的可入场／可用餐时段）" [level=2] [ref=e110]
              - region "回答表格，可横向滚动" [ref=e111]:
                - table [ref=e112]:
                  - rowgroup [ref=e113]:
                    - row [ref=e114]:
                      - columnheader "建议时段" [ref=e115]
                      - columnheader "安排" [ref=e116]
                      - columnheader "依据" [ref=e117]
                  - rowgroup [ref=e118]:
                    - row [ref=e119]:
                      - cell "08:30" [ref=e120]
                      - cell "杭州东站集合出发" [ref=e121]
                      - cell "建议" [ref=e122]
                    - row [ref=e123]:
                      - cell "08:30–09:05" [ref=e124]
                      - cell "地铁1号线至龙翔桥，步行到湖滨公园" [ref=e125]
                      - cell "约31分钟" [ref=e126]
                    - row [ref=e127]:
                      - cell "09:05–09:20" [ref=e128]
                      - cell "湖滨公园 → 断桥残雪，步行约1.1公里" [ref=e129]
                      - cell "约15分钟" [ref=e130]
                    - row [ref=e131]:
                      - cell "09:20–11:20" [ref=e132]
                      - cell "断桥、白堤方向沿湖步行游览，回到湖滨" [ref=e133]
                      - cell "建议时长" [ref=e134]
                    - row [ref=e135]:
                      - cell "11:25–11:30" [ref=e136]
                      - cell "步行至午餐门店（约0.2公里）" [ref=e137]
                      - cell "约3分钟" [ref=e138]
                    - row [ref=e139]:
                      - cell "11:30–12:40" [ref=e140]
                      - cell "午餐（见第四节）" [ref=e141]
                      - cell "建议" [ref=e142]
                    - row [ref=e143]:
                      - cell "12:45–13:30" [ref=e144]
                      - cell "公交27路至双峰站，步行458米到双峰馆区" [ref=e145]
                      - cell "约45分钟" [ref=e146]
                    - row [ref=e147]:
                      - cell "13:40–16:00" [ref=e148]
                      - cell "中国茶叶博物馆双峰馆区参观" [ref=e149]
                      - cell "该馆网站称开放9:00–16:30" [ref=e150]
                    - row [ref=e151]:
                      - cell "16:05–17:10" [ref=e152]
                      - cell "公交180路＋地铁19号线＋1号线回杭州东站" [ref=e153]
                      - cell "约62分钟" [ref=e154]
              - heading "三、逐段交通（均为查询结果）" [level=2] [ref=e155]
              - list [ref=e156]:
                - listitem [ref=e157]:
                  - paragraph [ref=e158]:
                    - strong [ref=e159]: 杭州东站 → 杭州西湖风景名胜区-湖滨公园｜地铁为主，约9.0公里，约31分钟
                    - text: 地铁1号线(萧山国际机场--湘湖)，上车站“火车东站”（D口进），下车站“龙翔桥”（B口出）；含步行合计约811米。备选：地铁4号线→钱江路换2号线→凤起路，约5.5公里级路线、总约55分钟，步行约1634米，比前者慢。
                - listitem [ref=e160]:
                  - paragraph [ref=e161]:
                    - strong [ref=e162]: 杭州西湖风景名胜区-湖滨公园 → 杭州西湖风景名胜区-断桥残雪｜步行，约1.1公里，约15分钟
                - listitem [ref=e163]:
                  - paragraph [ref=e164]:
                    - strong [ref=e165]: 杭州西湖风景名胜区-湖滨公园 → 荷韵西子·老底子杭帮菜(西湖音乐喷泉店)｜步行，约0.2公里，约3分钟
                - listitem [ref=e166]:
                  - paragraph [ref=e167]:
                    - strong [ref=e168]: 荷韵西子·老底子杭帮菜(西湖音乐喷泉店) → 中国茶叶博物馆(双峰馆区)｜公交，约6.5公里，约45分钟
                    - text: 步行约252米至“小车桥”，乘27路(岳王路--茶博龙井馆区)，上车站“小车桥”，下车站“双峰”，再步行约458米到馆。
                - listitem [ref=e169]:
                  - paragraph [ref=e170]:
                    - strong [ref=e171]: 中国茶叶博物馆(双峰馆区) → 杭州东站｜公交＋地铁，约15.3公里，约62分钟
                    - text: 步行约424米至“里鸡笼山”，乘180路(钱江湾花园总站--金色蓝庭总站)至“皇朝花园(五联村)”，步行约232米至“五联”，乘地铁19号线(火车西站--永盛路)至“西湖文化广场”，换乘地铁1号线(湘湖--萧山国际机场)至“火车东站”，步行约94米。 备选（较慢）：步行约398米至“双峰”，乘27路(茶博龙井总站--岳王路)至“小车桥”，步行约631米至“凤起路”，乘地铁1号线至“火车东站”，约15.3公里、约85分钟。
              - paragraph [ref=e172]: 说明：公交工具未说明上述耗时是否包含候车等时间；线路名按工具返回原样引用；其中5条中的180路、19号线为两个不同运营方线路，换乘站点如工具所示。
              - heading "四、午餐推荐（湖滨，1家）" [level=2] [ref=e173]
              - paragraph [ref=e174]:
                - strong [ref=e175]: 荷韵西子·老底子杭帮菜（西湖音乐喷泉店）
              - list [ref=e176]:
                - listitem [ref=e177]: 地址：长生路66号（西湖国贸靠停车场入口侧）；高德类型“中餐厅”；高德人均约64元，高德评分4.5，营业时间10:00–23:00（均为高德返回字段）。
                - listitem [ref=e178]:
                  - text: 推荐理由：在湖滨公园步行约0.2公里的范围内，午餐后到“小车桥”乘车去双峰馆区顺路（该段路线已查询）。店名含“杭帮菜”关键词，
                  - strong [ref=e179]: 实际菜品、口味与是否清淡待核实
                  - text: ，点餐可询问店家。
              - heading "五、开放／预约信息（按您要求核实，区分已读与未读）" [level=2] [ref=e180]
              - paragraph [ref=e181]:
                - strong [ref=e182]: 西湖（环湖公共区域：湖滨公园、断桥）
              - list [ref=e183]:
                - listitem [ref=e184]:
                  - text: 西湖风景名胜区管委会2020年7月2日函件（正文已读）：称“西湖环湖景区和综合整治后新增的景区全部实行了免费开放”“西湖24小时全天候免费开放”，并称当时仍有18处公园景点实行门票制度（如灵隐飞来峰、岳庙等）。该文为2020年对人大建议的答复，属当时政策表述，
                  - strong [ref=e185]: 不构成2026年11月14日当日一定开放或免费的确认
                  - text: 。
                - listitem [ref=e186]: 高德地点详情：杭州西湖风景名胜区、湖滨公园、断桥残雪均标注“24小时营业”。
                - listitem [ref=e187]:
                  - text: 杭州市文化广电旅游局页面（2021年10月22日）
                  - strong [ref=e188]: 仅取得搜索摘录、未读正文
                  - text: ，摘录写“开始时间：全天”。
                - listitem [ref=e189]:
                  - text: 综合：环湖公共区域按资料为免费、全天开放；
                  - strong [ref=e190]: 我没有取得针对2026年11月14日的景区公告，当日是否有临时管控或调整待核实
                  - text: 。
              - paragraph [ref=e191]:
                - strong [ref=e192]: 中国茶叶博物馆（双峰馆区）
              - list [ref=e193]:
                - listitem [ref=e194]: 中国茶叶博物馆网站“参观指南”页（teamuseum.cn，正文已读）：开放时间9:00–16:30，并写“每周二为闭馆日，节假日照常开放”。页面未标注发布日期，为常规规则。
                - listitem [ref=e195]: 高德地点详情：周二全天不开放，周一、周三至周日09:00–16:30开放，节假日09:00–16:30。
                - listitem [ref=e196]:
                  - text: 杭州市文化广电旅游局2022年11月9日页面（
                  - strong [ref=e197]: 仅取得摘录、未读正文
                  - text: ）：摘录写“周二至周日09:00–16:30；周一闭馆”。
                  - strong [ref=e198]: 与上述资料在“周一还是周二闭馆”上存在矛盾
                  - text: ，请以出行前该馆公布信息为准。
                - listitem [ref=e199]:
                  - text: 预约：杭州本地宝2026年8月6日转载的该馆“关于优化开放服务实行免预约入馆的公告”（正文已读）：称双峰馆区与龙井馆区全面实行免预约入馆，个人及散客无需线上预约，入馆前需配合安全检查；团队参观需准备盖章人员名单并发送至邮箱。该页为第三方转载，
                  - strong [ref=e200]: 来源身份未经独立确认
                  - text: ，只能表述为“该资料称”。
                - listitem [ref=e201]:
                  - text: 门票价格：
                  - strong [ref=e202]: 本次未取得明确说明，待核实
                  - text: 。
                - listitem [ref=e203]:
                  - text: 2026年10月国庆期间“09:00–17:00、16:45停止入馆”的公告（第三方转载）仅覆盖10月1—7日，
                  - strong [ref=e204]: 不适用于11月14日
                  - text: 。
                - listitem [ref=e205]:
                  - text: 结论：11月14日为周六，与“周二闭馆”的常规规则不冲突，但
                  - strong [ref=e206]: 当日是否正常开放、是否有临时限流，仍需出行前核实
                  - text: 。
              - heading "六、来源清单" [level=2] [ref=e207]
              - list [ref=e208]:
                - listitem [ref=e209]:
                  - text: 中国茶叶博物馆网站·参观指南：
                  - link "https://www.teamuseum.cn/mobile/basicIntroduction.htm" [ref=e210] [cursor=pointer]:
                    - /url: https://www.teamuseum.cn/mobile/basicIntroduction.htm
                  - text: （正文已读；查询时间2026-11-08 18:35，北京时间；无发布日期；适用范围为未标日期的常规规则；正文可能截断）
                - listitem [ref=e211]:
                  - text: 中国茶叶博物馆“免预约入馆”公告（杭州本地宝转载）：
                  - link "http://hz.bendibao.com/tour/202686/172159.shtm" [ref=e212] [cursor=pointer]:
                    - /url: http://hz.bendibao.com/tour/202686/172159.shtm
                  - text: （正文已读；查询时间2026-11-08 18:35；页面日期2026-08-06；第三方转载，身份未确认）
                - listitem [ref=e213]:
                  - text: 杭州西湖风景名胜区管委会·建议办理函：
                  - link "https://westlake.hangzhou.gov.cn/art/2020/7/2/art_1229452857_59014809.html" [ref=e214] [cursor=pointer]:
                    - /url: https://westlake.hangzhou.gov.cn/art/2020/7/2/art_1229452857_59014809.html
                  - text: （正文已读；查询时间2026-11-08 18:36；发布日期2020-07-02；适用范围为当时政策）
                - listitem [ref=e215]:
                  - text: 杭州市文化广电旅游局·西湖风景区：
                  - link "https://wgly.hangzhou.gov.cn/art/2021/10/22/art_1229578164_58938617.html" [ref=e216] [cursor=pointer]:
                    - /url: https://wgly.hangzhou.gov.cn/art/2021/10/22/art_1229578164_58938617.html
                  - text: （仅搜索摘录，未读正文；查询时间2026-11-08 18:36）
                - listitem [ref=e217]:
                  - text: 杭州市文化广电旅游局·中国茶叶博物馆：
                  - link "https://wgly.hangzhou.gov.cn/art/2022/11/9/art_1229696394_58942345.html" [ref=e218] [cursor=pointer]:
                    - /url: https://wgly.hangzhou.gov.cn/art/2022/11/9/art_1229696394_58942345.html
                  - text: （仅搜索摘录，未读正文；发布日期2022-11-09）
                - listitem [ref=e219]:
                  - text: 杭州政协网《9月杭州西湖进入秋季旅游旺季…》：
                  - link "https://www.hzzx.gov.cn/cshz/content/2026-09/08/content_9301630.htm" [ref=e220] [cursor=pointer]:
                    - /url: https://www.hzzx.gov.cn/cshz/content/2026-09/08/content_9301630.htm
                  - text: （仅搜索摘录，未读正文；发布日期2026-09-08）
                - listitem [ref=e221]: 高德地点详情：杭州东站(B023B08WDR)、杭州西湖风景名胜区(B023B13L9M)、湖滨公园(B023B05MLT)、断桥残雪(B023B01EE6)、中国茶叶博物馆双峰馆区(B023B13PFT)、荷韵西子(B0JK2HTEUB)，查询时间2026-11-08 18:35。
              - heading "七、出行提醒与待核实项" [level=2] [ref=e222]
              - list [ref=e223]:
                - listitem [ref=e224]:
                  - text: 上述资料称：9—11月双休日西湖景区实行分时段交通管理（小客车单双号、灵隐区域与南山路部分路段限量，灵隐飞来峰需提前实名预约）。该内容来自摘录、未读正文，
                  - strong [ref=e225]: 主要影响自驾，本行程用地铁公交不受该限行约束
                  - text: ；如临时改自驾，请以当日公告为准。
                - listitem [ref=e226]:
                  - text: 若您想改去灵隐飞来峰等收费景点，需另行预约（资料提到“杭州灵隐飞来峰”小程序）；若需为收费景点购票，资料提到的入口是“西湖旅游”微信公众号预约购票页（来源：杭州本地宝
                  - link "http://hz.bendibao.com/tour/2020430/ly85286.shtm" [ref=e227] [cursor=pointer]:
                    - /url: http://hz.bendibao.com/tour/2020430/ly85286.shtm
                  - text: ），本次行程的环湖区域与双峰馆区按现有资料无需购票，但门票政策请出行前自行核实。
                - listitem [ref=e228]: 未取得或待核实：11月14日天气、茶叶博物馆门票价格、两处目的地当日临时公告、双峰馆区当日是否限流、公交实际班次与候车时间。
                - listitem [ref=e229]: 茶博咨询电话（据第三方转载资料）：0571-87969161。
              - paragraph [ref=e230]: 需要我把双峰馆区换成龙井馆区，或压缩西湖段、提早到馆参观吗？
            - button "复制完整回答" [ref=e231] [cursor=pointer]
      - generic [ref=e233]:
        - generic [ref=e234]: 旅行需求
        - textbox "旅行需求" [ref=e235]:
          - /placeholder: 写下城市、日期和你想查询的内容…
        - generic [ref=e236]:
          - paragraph [ref=e237]: 继续此会话 · 切换会话保留草稿
          - button "发送旅行需求" [disabled] [ref=e238]:
            - generic [ref=e241]: 发送
```

# Test source

```ts
  8   |   test.skip(process.env.POTATO_LIVE_ANSWER !== '1', '仅在显式真实模型联合验收时运行');
  9   |   test.setTimeout(900_000);
  10  |   const url = 'https://localhost:18499';
  11  |   const get = async (path: string) => (await page.request.get(url + path)).json();
  12  |   const mark = async (key: string, data: object) => page.request.post(url + '/__acceptance__/coordination/' + key, {data});
  13  |   const environment = await get('/__acceptance__/environment');
  14  |   expect(environment.kind).toBe('configured-model-answer-acceptance');
  15  |   await page.addInitScript(() => {
  16  |     const evidence = {receipts: [] as object[], rendered: [] as object[]};
  17  |     (window as any).__liveEvidence = evidence;
  18  |     const Native = window.EventSource;
  19  |     window.EventSource = class extends Native {
  20  |       constructor(address: string | URL, options?: EventSourceInit) {
  21  |         super(address, options);
  22  |         for (const kind of ['answer.preview', 'progress.preview', 'service.state']) {
  23  |           this.addEventListener(kind, event => {
  24  |             const notice = JSON.parse((event as MessageEvent).data);
  25  |             const value = kind === 'service.state' ? notice.state : notice.preview;
  26  |             evidence.receipts.push({epoch_ms: Date.now(), monotonic_ms: performance.now(), kind,
  27  |               content: value == null ? null : {
  28  |                 instance_id: value.instance_id, stream_id: value.stream_id, session_id: value.session_id,
  29  |                 turn_id: value.turn_id, revision: value.revision, attempt_id: value.attempt_id,
  30  |                 status: value.status, delivery: value.delivery, text_chars: value.text?.length,
  31  |                 entries: value.entries?.map((entry: any) => ({id: entry.id, attempt_id: entry.attempt_id,
  32  |                   kind: entry.kind, status: entry.status, text_chars: entry.text.length})),
  33  |                 active_turn_id: value.active_turn_id,
  34  |               }});
  35  |           });
  36  |         }
  37  |       }
  38  |     };
  39  |     let previous = '';
  40  |     let heartbeat = 0;
  41  |     const sample = () => {
  42  |       const turn = document.querySelector('section[aria-label="第 2 轮对话"]');
  43  |       const body = turn?.querySelector<HTMLElement>('.message.answer .answer-body');
  44  |       const progress = turn?.querySelector<HTMLDetailsElement>('.query-progress');
  45  |       const text = body?.innerText ?? '';
  46  |       const query = progress?.open ? Array.from(progress.querySelectorAll<HTMLElement>('li > span')).map(item => item.innerText).join('\n') : '';
  47  |       const status = progress?.open ? Array.from(progress.querySelectorAll<HTMLElement>('li > small')).map(item => item.innerText) : [];
  48  |       const scroll = document.querySelector('.messages');
  49  |       const state = {rendered_document_chars: text.length, rendered_progress_chars: query.length,
  50  |         progress_open: progress?.open ?? null, progress_statuses: status,
  51  |         copy_label: turn?.querySelector('.message.answer button')?.textContent ?? null,
  52  |         scroll_top: scroll?.scrollTop ?? null, scroll_height: scroll?.scrollHeight ?? null,
  53  |         viewport_height: scroll?.clientHeight ?? null};
  54  |       const serial = JSON.stringify(state);
  55  |       const now = performance.now();
  56  |       if (serial !== previous || now - heartbeat >= 100) {
  57  |         evidence.rendered.push({epoch_ms: Date.now(), monotonic_ms: now, time_origin: performance.timeOrigin, ...state});
  58  |         previous = serial; heartbeat = now;
  59  |       }
  60  |       requestAnimationFrame(sample);
  61  |     };
  62  |     requestAnimationFrame(sample);
  63  |   });
  64  |   await page.goto(url);
  65  |   let coordination: any;
  66  |   await expect.poll(async () => {
  67  |     coordination = await get('/__acceptance__/coordination');
  68  |     return coordination.ios_session?.session_id;
  69  |   }, {timeout: 240_000}).toBeTruthy();
  70  |   const id = coordination.ios_session.session_id;
  71  |   const session = page.locator('.history-select').first();
  72  |   await expect(session).toBeVisible({timeout: 30_000});
  73  |   await session.click();
  74  |   await expect(page.locator('section[aria-label="第 1 轮对话"] .answer-body')).toBeVisible();
  75  |   await mark('web_ready', {session_id: id, at: new Date().toISOString()});
  76  |   let saved: any;
  77  |   await expect.poll(async () => {
  78  |     saved = await get('/api/sessions/' + id + '?summary=false&include_messages=false');
  79  |     return saved.turns[1]?.status;
  80  |   }, {timeout: 600_000, intervals: [500]}).not.toBe(undefined);
  81  |   const target = saved.turns[1].turn_id;
  82  |   await expect.poll(async () => {
  83  |     saved = await get('/api/sessions/' + id + '?summary=false&include_messages=false');
  84  |     return saved.turns[1].status;
  85  |   }, {timeout: 600_000, intervals: [500]}).not.toBe('running');
  86  |   const turn = saved.turns[1];
  87  |   expect(turn.status).toBe('completed');
  88  |   await expect(page.locator('section[aria-label="第 2 轮对话"]').getByRole('button', {name: '复制完整回答', exact: true})).toBeVisible();
  89  |   await page.waitForTimeout(300);
  90  |   const timeline = await page.evaluate(() => (window as any).__liveEvidence);
  91  |   const samples = timeline.rendered.filter((sample: any) => sample.rendered_document_chars > 0);
  92  |   expect(samples.length).toBeGreaterThan(2);
  93  |   expect(timeline.receipts.some((item: any) => item.kind === 'answer.preview' && item.content?.turn_id === target && item.content.text_chars > 0)).toBeTruthy();
  94  |   const query = page.locator('section[aria-label="第 2 轮对话"] .query-progress');
  95  |   if (environment.scenario === 'query') {
  96  |     expect(turn.query_progress.length).toBeGreaterThan(0);
  97  |     expect(saved.tool_calls.filter((item: any) => item.turn_id === target).length).toBeGreaterThan(0);
  98  |     await expect(query).not.toHaveAttribute('open');
  99  |     expect(timeline.rendered.some((item: any) => item.rendered_progress_chars > 0)).toBeTruthy();
  100 |     await query.locator('summary').click();
  101 |     await expect(query).toHaveAttribute('open');
  102 |   } else {
  103 |     expect(turn.query_progress).toEqual([]);
  104 |     expect(saved.tool_calls.filter((item: any) => item.turn_id === target)).toEqual([]);
  105 |   }
  106 |   await page.screenshot({path: test.info().outputPath('live-saved-expanded.png')});
  107 |   // 系统剪贴板由两端共享：等待手机完成采样，再先由Web复制，最后交手机。
> 108 |   await expect.poll(async () => (await get('/__acceptance__/coordination')).ios_saved, {timeout: 120_000}).toBeTruthy();
      |                                                                                                            ^ Error: expect(received).toBeTruthy()
  109 |   await page.context().grantPermissions(['clipboard-read', 'clipboard-write']);
  110 |   await page.locator('section[aria-label="第 2 轮对话"]').getByRole('button', {name: '复制完整回答', exact: true}).click();
  111 |   expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(turn.answer);
  112 |   await mark('web_copied', {turn_id: target, markdown_equal: true});
  113 |   await page.reload();
  114 |   await page.locator('.history-select').first().click();
  115 |   const history = await get('/api/sessions/' + id + '?summary=false&include_messages=false');
  116 |   expect(history.turns[1].query_progress).toEqual(turn.query_progress);
  117 |   expect(history.turns[1].answer).toBe(turn.answer);
  118 |   if (environment.scenario === 'query') {
  119 |     const reopened = page.locator('section[aria-label="第 2 轮对话"] .query-progress');
  120 |     await expect(reopened).not.toHaveAttribute('open');
  121 |     await reopened.locator('summary').click();
  122 |     await expect(reopened).toContainText('已保存的查询进展');
  123 |   }
  124 |   await page.screenshot({path: test.info().outputPath('live-reopened.png')});
  125 |   const evidence = test.info().outputPath('live-evidence.json');
  126 |   await writeFile(evidence, JSON.stringify({environment, session_id: id, turn_id: target, timeline,
  127 |     outcome: turn, requests: history.requests, tools: history.tool_calls.map((item: any) => ({
  128 |       tool_call_id: item.tool_call_id, turn_id: item.turn_id, name: item.name, status: item.status})),
  129 |     copy_markdown_equal: true, reloaded_progress_equal: true}, null, 2));
  130 |   await test.info().attach('真实模型与 Web 全程证据', {path: evidence, contentType: 'application/json'});
  131 |   await mark('web_finished', {turn_id: target, at: new Date().toISOString()});
  132 | });
  133 | 
```